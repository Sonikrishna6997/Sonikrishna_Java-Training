package Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class City {
    private String name;
    private long pincode;
    private String capital_city;
   
    // Constructor
    public City(String name, long pincode, String capital_city) {
        this.name = name;
        this.pincode = pincode;
        this.capital_city = capital_city;
    }
   
    // Getter and Setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPincode() {
        return pincode;
    }

    public void setPincode(long pincode) {
        this.pincode = pincode;
    }

    public String getCapitalCity() {
        return capital_city;
    }

    public void setCapitalCity(String capital_city) {
        this.capital_city = capital_city;
    }

    // toString method
    @Override
    public String toString() {
        return "City [name=" + name + ", pincode=" + pincode + ", capital_city=" + capital_city + "]";
    }
}

public class CityList {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);
       
        // Create a list of City
        List<City> cities = new ArrayList<>();
       
        // Input number of cities
        System.out.print("Enter the number of cities: ");
        int numberOfCities = scanner.nextInt();
        scanner.nextLine(); // Consume the newline
       
        // Input city details
        for (int i = 0; i < numberOfCities; i++) {
            System.out.println("Enter details for city " + (i + 1) + ":");
           
            System.out.print("Name: ");
            String name = scanner.nextLine();
           
            System.out.print("Pincode: ");
            long pincode = scanner.nextLong();
            scanner.nextLine(); // Consume the newline
           
            System.out.print("Capital City: ");
            String capitalCity = scanner.nextLine();
           
            // Create a new City object and add it to the list
            cities.add(new City(name, pincode, capitalCity));
        }
       
        // Close the scanner
        scanner.close();
       
        // Iterate and display city details
        Iterator<City> itr = cities.iterator();
        while (itr.hasNext()) {
            City city = itr.next();
            System.out.println(city);
        }
    }
}