package RevisionDay3;
import java.util.HashMap;
public class HashMapEg {
public static void main(String[] args) {
        
        HashMap<String, Boolean> hm = new HashMap<>();
        
        
        hm.put("aaaaadd", true);
        hm.put("rgsegehgreh", true);
        hm.put("nnnnnn", true); 
        hm.put("trhrt", true);
        hm.put("rerww", true); 
        hm.put("ertweeryerwtw", true);
        hm.put("rwwettwrrytrj", true);

        // Using forEach correctly to print keys
        hm.keySet().stream().forEach(key -> System.out.println(key));
    }
}
