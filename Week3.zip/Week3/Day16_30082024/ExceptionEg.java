package ExceptionHandling;

public class ExceptionEg {
	public static void main()
	{ 
		try {
		int arr[]= {1,2,3,4,5,6};
		for(int i=0;i<=arr.length;i++)
		{System.out.println(arr[i]);
		
		}
			//Stms1;
		met();
		//Stms1;
		}
		catch(Exception e)
		{
			System.out.println("Exception Ocuured");
			e.printStackTrace();
		}
	}
		static void met() throws Exception{
		System.out.println("1.....");
		try {
		String str="sdfsdfs";
		int val = Integer.parseInt(str);
		System.out.println("2.....");
		val*=1.1;
		System.out.println(val);
		}
		catch(Exception e)
		{
		System.out.println("Exception occured..Please retry with different input");
		
	}
		System.out.println("3.....");
	}

}
