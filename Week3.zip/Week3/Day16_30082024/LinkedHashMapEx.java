package RevisionDay3;
import java.util.*;
import java.util.Map.Entry;
public class LinkedHashMapEx {
	public static void main(String[] args) {
		LinkedHashMap<String, String>lmss=new LinkedHashMap<>();
		lmss.put("adddd", "dfgsdsdsdg");
		lmss.put("wer", "drtdgd");
		lmss.put("wer", "cvbdfgfdcg");
		lmss.put("adddd", "rtytyu");
		lmss.put("adddfgdfgddd", "ertert");
		lmss.put("dfrt", "ghjghj");
		lmss.put("e4ert", "ert");
		Set<Entry<String,String>> sess=lmss.entrySet();
		for(Entry<String,String> ess:sess) {
			System.out.println(ess.getKey()+"-->"+ess.getValue());
		}
		
	}

}
