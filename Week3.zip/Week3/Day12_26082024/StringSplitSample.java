package Collection;

public class StringSplitSample {
	public static void main(String[] args) {
        String str = "This,is,to,test";
        
        // Split the string by comma
        String[] substrings = str.split(", ");
        
        // Print the first substring
        if (substrings.length > 0) {
            System.out.println(substrings[0]);
        }
        
        // Print the last substring
        if (substrings.length > 0) {
            System.out.println(substrings[substrings.length - 1]);
        }
    }

}
