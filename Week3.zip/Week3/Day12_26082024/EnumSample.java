package Collection;
enum Day {
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
};
public class EnumSample {
	Day day = Day.MONDAY;

	public static void main(String[] a) {

		Day today = Day.WEDNESDAY;
		printWeekend(today);
	}

	// an enum type can be used as local variable, parameter
	static public void printWeekend(Day today) {
		if (today == Day.SATURDAY) {
			System.out.println("It's Weekend, Saturday");
		} else if (today == Day.SUNDAY) {
			System.out.println("It's Weekend, Sunday");
		} else {
			System.out.println("It's not Weekend");
		}
		switch(today) {
		case Day.MONDAY:
			System.out.println("Today is Monday");
			break;
		case Day.TUESDAY:
			System.out.println("Today is TUESDAY");
			break;
		case Day.WEDNESDAY:
			System.out.println("Today is WEDNESDAY");
			break;
			default:
				System.out.println("Today is not MONDAY,TUESDAY,WEDNESDAY");	
		}
	}

	//an enum type can be used as return type
	Day getSunday() {
		return Day.SUNDAY;
	}

}
