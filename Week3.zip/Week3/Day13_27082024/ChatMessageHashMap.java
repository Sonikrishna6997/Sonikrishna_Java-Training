package Revision;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
public class ChatMessageHashMap {
	public static void main(String [] args) {
		HashMap<String,String> hmss=new HashMap<>();
		hmss.put("name1", "msg99");
		hmss.put("name2", "msg199");
		hmss.put("name3", "msg299");
		hmss.put("name4", "msg399");
		hmss.put("name5", "msg499");
		hmss.put("name6", "msg599");
		Set<String> ss=hmss.keySet();
		for(String item_key:ss) {
			//System.out.println(item_key+"--->"+hmss.get(item_key));
		}
		
		 TreeMap<String, String> tmss = new TreeMap<>(Comparator.reverseOrder());

	        // Adding entries to the TreeMap
	        tmss.put("name1", "msg99");
	        tmss.put("name2", "msg199");
	        tmss.put("name3", "msg299");
	        tmss.put("name4", "msg399");
	        tmss.put("name5", "msg499");
	        tmss.put("name6", "msg599");
	        System.out.println("\nPrinting in treemap\n");

	        // Iterating over the TreeMap and printing the entries
	        for (Map.Entry<String, String> entry : tmss.entrySet()) {
	            System.out.println(entry.getKey() + "--->" + entry.getValue());
	}

}

}
