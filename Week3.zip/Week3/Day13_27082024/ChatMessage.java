package Revision;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
class Chats {
    private String sender_name;
    private String msg;
    
    public Chats(String sender_name, String msg) {
        this.sender_name = sender_name;
        this.msg = msg;
    }
    
    @Override
    public String toString() {
        return "Chats [sender_name=" + sender_name + ", msg=" + msg + "]";
    }
}
public class ChatMessage {
	public static void main(String[] args) {
        List<Chats> msgs = new LinkedList<>();
        
        // Create Chats objects and add to the linked list
        msgs.add(new Chats("P13", "D"));
        msgs.add(new Chats("P2", "S"));
        msgs.add(new Chats("P9", "d"));
        msgs.add(new Chats("P8", "N"));
        msgs.add(new Chats("P13", "e"));
        msgs.add(new Chats("P5", "Y"));
        msgs.add(new Chats("P8", "I"));
        msgs.add(new Chats("P9", "completed"));
        
        // Display the original list
        System.out.println("Original chat messages:");
        display(msgs);
        
        // Reverse the linked list
        reverseList(msgs);
        
        // Display the reversed list
        System.out.println("\nReversed chat messages:");
        display(msgs);
        
        // Reverse the list again to restore original order
        reverseList(msgs);
        
        // Display the restored list
        System.out.println("\nRestored original chat messages:");
        display(msgs);
    }
    
    // Method to display the list of Chats objects
    static void display(List<Chats> list) {
        for (Chats chat : list) {
            System.out.println(chat);
        }
    }
    
    // Method to reverse the linked list
    static void reverseList(List<Chats> list) {
        LinkedList<Chats> reversedList = new LinkedList<>();
        
        // Iterate over the original list and add elements to the reversed list
        ListIterator<Chats> iterator = list.listIterator(list.size());
        while (iterator.hasPrevious()) {
            reversedList.add(iterator.previous());
        }
        
        // Clear the original list and add all elements from the reversed list
        list.clear();
        list.addAll(reversedList);
    }

}
