package Day17;

public class ExceptionHandlingEg {
	public static void main(String[] args)
	{ 
		try {
			String str ="gabcd";
			String substr=str.substring(2,9);
			int arr[]= {1,2,3,4,5,6};
		for(int i=0;i<=arr.length;i++)
		{
			
			System.out.println(arr[i]);
		
		}//ArrayIndexOutOfBoundsException
			//Stms1;
		met();
		//Stms1;
		}
		catch(StringIndexOutOfBoundsException se)
		{
			System.out.println("String Index Ocuured"+se);
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println("String Index Ocuured"+ae);
		}
		catch(NumberFormatException ne)
		{
			System.out.println("Number format Exception"+ne);
		}
		catch(Exception e)
		{
			System.out.println("Exception Ocuured");
			e.printStackTrace();
		}
		finally {
			System.out.println("Finally");
		}
	}
		static void met() throws Exception{
		System.out.println("1.....");
		try {
		String str="sdfsdfs";
		int val = Integer.parseInt(str);
		System.out.println("2.....");
		val*=1.1;
		System.out.println(val);
		}
		catch(Exception e)
		{
		System.out.println("Exception occured..Please retry with different input");
		
	}
		System.out.println("3.....");
	}
}
