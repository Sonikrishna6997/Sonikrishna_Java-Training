
public class PetrolPriceAverage {

	public static void main(String[] args) {
		Double[] petrolPrices= {91.2,96.4,92.7,98.9,95.6,90.1};
		double sum=0;
		for(int i=0;i<petrolPrices.length;i++)
		{
			sum+=petrolPrices[i];
	
		}
		double averagePrice=sum/petrolPrices.length;
		System.out.println("The average of Petrol price is " +averagePrice);
	}

}
